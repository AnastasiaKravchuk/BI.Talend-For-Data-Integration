--------------------------------------------------------
--  File created - Monday-August-20-2018   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table PAYMENTS_DATA
--------------------------------------------------------

  CREATE TABLE PAYMENTS_DATA
   (	
    PAYMENTID               NUMBER, 
	CUSTOMERID              NUMBER, 
    PRODUCTID               NUMBER, 
	TRANSACTIONDATE         DATE, 
	CREDITCARD              VARCHAR2(30 BYTE), 
	CREDITCARDNUMBER        VARCHAR2(30 BYTE)
   );
