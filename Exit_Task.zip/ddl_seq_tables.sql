--==============================================================================================================================
--SEQUENCES
--==============================================================================================================================

CREATE SEQUENCE SEQ_PRODUCTS
START WITH     1
 INCREMENT BY   1
 NOCACHE
 NOCYCLE;
 
--------------------------------------------------------------------------------------------------------------------------------
 
 CREATE SEQUENCE SEQ_CUSTOMERS
START WITH     1
 INCREMENT BY   1
 NOCACHE
 NOCYCLE;
 
--==============================================================================================================================
--TABLES
--==============================================================================================================================
--------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE filenames
(
    filename VARCHAR2(40)
);
--------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE SRC_CUSTOMERS
   (	
    ID NUMBER, 
    NAME VARCHAR2(30 BYTE), 
	USERNAME VARCHAR2(30 BYTE), 
	EMAIL VARCHAR2(50 BYTE), 
	DATEOFBIRTH DATE, 
	STREETADDRESS VARCHAR2(50 BYTE), 
	CITY VARCHAR2(50 BYTE), 
	COUNTRY VARCHAR2(50 BYTE), 
	ZIP VARCHAR2(6 BYTE), 
	STATE VARCHAR2(2 BYTE), 
    PHONE VARCHAR2(14 BYTE)
   );
--------------------------------------------------------------------------------------------------------------------------------

CREATE TABLE SRC_PRODUCTS
   (	
    PRODUCTS" NUMBER, 
    PRODUCTNAMEVARCHAR2(120 BYTE), 
	COMPANYNAME VARCHAR2(50 BYTE), 
	PRICE FLOAT(126), 
	WAREHOUSELOCATIONSTATE VARCHAR2(2 BYTE)
   );
--------------------------------------------------------------------------------------------------------------------------------

  CREATE TABLE SRC_PURCHASE
   (	
    PAYMENTID NUMBER, 
    CUSTOMERID NUMBER, 
	PRODUCTID NUMBER, 
	TRANSACTIONDATE DATE, 
	CREDITCARD VARCHAR2(50 BYTE), 
	CREDITCARDNUMBER VARCHAR2(50 BYTE)
   );
   
--------------------------------------------------------------------------------------------------------------------------------
CREATE TABLE DM_CUSTOMERS
(
    SURR_ID NUMBER,
    CUSTOMER_ID NUMBER, 
    CUSTOMER_NAME VARCHAR2(40),
    CUSTOMER_USERNAME VARCHAR2(40),
    CUSTOMER_EMAIL VARCHAR2(50),
    CUSTOMER_DATE_OF_BIRTH DATE,
    CUSTOMER_STREET_ADDRESS VARCHAR2(50),
    CUSTOMER_CITY VARCHAR2(50),
    CUSTOMER_COUNTRY VARCHAR2(50),
    CUSTOMER_ZIP VARCHAR2(6),
    CUSTOMER_STATE VARCHAR2(2),
    CUSTOMER_PHONE VARCHAR2(14)
);
--------------------------------------------------------------------------------------------------------------------------------

CREATE TABLE DM_PRODUCTS
(
    SURR_ID NUMBER,
    PRODUCT_ID NUMBER,
    PRODUCT_NAME VARCHAR2(120),
    COMPANY_NAME VARCHAR2(50),
    PRICE NUMBER(6,2),
    WAREHOUSE_LOCATION_STATE VARCHAR2(2)
);
--------------------------------------------------------------------------------------------------------------------------------
  CREATE TABLE DM_DATE
   (	
    DATE_ID VARCHAR2(20 BYTE), 
	FULL_DATE DATE, 
	DAY_OF_WEEK_IN_MONTH NUMBER, 
	DAY_IN_MONTH NUMBER, 
	DAY_IN_YEAR NUMBER, 
	WEEK_NUMBER NUMBER, 
	MONTH_NUMBER NUMBER, 
	MONTH_NAME VARCHAR2(20 BYTE), 
	QUATER NUMBER, 
	YEAR NUMBER
   );
--------------------------------------------------------------------------------------------------------------------------------

CREATE TABLE fct_purchase_dm
(
    PAYMENT_ID NUMBER,
    CUSTOMER_ID NUMBER,
    PRODUCT_ID NUMBER,
    EVENT_DT VARCHAR2(10),
    CREDIT_CARD VARCHAR2(20),
    CREDIT_CARD_NUMBER VARCHAR2(30),
    ISINTERSTATE CHAR(1)
);
--------------------------------------------------------------------------------------------------------------------------------

CREATE TABLE DIM_PRODUCTS
(
    SURR_ID NUMBER,
    PRODUCT_ID NUMBER,
    PRODUCT_NAME VARCHAR2(120),
    COMPANY_NAME VARCHAR2(50),
    PRICE NUMBER(6,2),
    WAREHOUSE_LOCATION_STATE VARCHAR2(2)
);



--------------------------------------------------------------------------------------------------------------------------------

CREATE TABLE DIM_CUSTOMERS
(
    SURR_ID NUMBER,
    CUSTOMER_ID NUMBER, 
    CUSTOMER_NAME VARCHAR2(40),
    CUSTOMER_USERNAME VARCHAR2(40),
    CUSTOMER_EMAIL VARCHAR2(50),
    CUSTOMER_DATE_OF_BIRTH DATE,
    CUSTOMER_STREET_ADDRESS VARCHAR2(50),
    CUSTOMER_CITY VARCHAR2(50),
    CUSTOMER_COUNTRY VARCHAR2(50),
    CUSTOMER_ZIP VARCHAR2(6),
    CUSTOMER_STATE VARCHAR2(2),
    CUSTOMER_PHONE VARCHAR2(14)
);

--------------------------------------------------------------------------------------------------------------------------------

  CREATE TABLE DIM_TIMES
   (	
    DATE_ID VARCHAR2(20 BYTE), 
	FULL_DATE DATE, 
	DAY_OF_WEEK_IN_MONTH NUMBER, 
	DAY_IN_MONTH NUMBER, 
	DAY_IN_YEAR NUMBER, 
	WEEK_NUMBER NUMBER, 
	MONTH_NUMBER NUMBER, 
	MONTH_NAME VARCHAR2(20 BYTE), 
	QUATER NUMBER, 
	YEAR NUMBER
   );
   
--------------------------------------------------------------------------------------------------------------------------------

CREATE TABLE fct_purchase
(
    PAYMENT_ID NUMBER,
    CUSTOMER_ID NUMBER,
    PRODUCT_ID NUMBER,
    EVENT_DT VARCHAR2(20),
    CREDIT_CARD VARCHAR2(20),
    CREDIT_CARD_NUMBER VARCHAR2(30),
    ISINTERSTATE CHAR(2)
);